# Description

Manages VM net adapters attached to a Hyper-V virtual machine or the
management OS.

## Requirements

* The Hyper-V Role has to be installed on the machine.
* The Hyper-V PowerShell module has to be installed on the machine.
