# Description

The xDnsRecordMx DSC resource manages MX DNS records against a specific zone
on a Domian Name System (DNS) server.
