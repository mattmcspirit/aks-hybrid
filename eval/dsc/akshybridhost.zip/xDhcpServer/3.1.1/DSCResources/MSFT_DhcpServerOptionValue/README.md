# Description

The DhcpServerOptionValue DSC resource manages option values at server level.

## Requirements

- Target machine must be running Windows Server 2012 R2 or later.
- Target machine must be running at minimum Windows PowerShell 5.0.
